import re
from django.db import models
from phonenumber_field.modelfields import PhoneNumberField
from django.contrib.auth.models import BaseUserManager, AbstractBaseUser
from django.core.exceptions import ValidationError
#  Custom User Manager


class UserManager(BaseUserManager):
    def create_user(self, email, phone, name, tc, dob,  password=None, password2=None):
        """
        Creates and saves a User with the given email, name, tc and password.
        """
        if not email:
            raise ValueError('User must have an email address')
        if not phone:
            raise ValueError('User must have an phone no')

        user = self.model(
            email=self.normalize_email(email),
            phone=phone,
            dob=dob,
            name=name,
            tc=tc,

        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, name, tc,phone ,dob, password=None):
        """
        Creates and saves a superuser with the given email, name, tc and password.
        """
        user = self.create_user(
            email,
            password=password,
            name=name,
            phone=phone,
            tc=tc,
            dob=dob,
        )
        user.is_admin = True
        user.save(using=self._db)
        return user

#  Custom User Model

def validate_us_phone_number(value):
    # Regular expression for US phone number formats
    phone_regex = re.compile(
        r'^(?:\+1[-.\s]?|1[-.\s]?|)?\(?([2-9][0-9]{2})\)?[-.\s]?([2-9][0-9]{2})[-.\s]?([0-9]{4})$'
    )
    # if not phone_regex.match(value):
    #     raise ValidationError('Invalid phone number format. Please enter a valid US mobile number.')

class User(AbstractBaseUser):
    #    uid= models.UUIDField(_("Unique ID"), primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField(
        verbose_name='Email',
        max_length=255,
        unique=True,
    )
    # phone = PhoneNumberField(unique=True)
    phone = models.CharField(
        max_length=15,
        # validators=[validate_us_phone_number],
        help_text='Enter a valid US mobile number.'
    )
    name = models.CharField(max_length=200)
    dob = models.DateField(auto_now=False, auto_now_add=False)
    tc = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['name', 'tc','phone','dob']

    def __str__(self):
        return self.name

    def has_perm(self, perm, obj=None):
        "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return self.is_admin

    def has_module_perms(self, app_label):
        "Does the user have permissions to view the app `app_label`?"
        # Simplest possible answer: Yes, always
        return True

    @property
    def is_staff(self):
        "Is the user a member of staff?"
        # Simplest possible answer: All admins are staff
        return self.is_admin
